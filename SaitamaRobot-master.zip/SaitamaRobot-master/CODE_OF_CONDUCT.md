# Contributor Code of Conduct

This project adheres to a **modified** No Code of Conduct.  We are all adults.  We accept anyone's contributions.  ~~Nothing else matters.~~

For more information on NCoC please visit the [No Code of Conduct](https://github.com/domgetter/NCoC) homepage.

In addition to the above clause in the Code of Conduct, the following clauses must be adhered to:
- Don't be an asshole. No one likes them. Please be friendly while making contributions.
- Don't act entitled to perks or Collaborator access just because of a contribution. (Refer to [Code of Merit](https://codeofmerit.org/code/) Clause 4)
- Individual characteristics, including but not limited to, body, sex, sexual preference, race, language, religion, nationality, or political preferences are irrelevant in the scope of the project and will not be taken into account concerning your value or that of your contribution to the project. ([Code of Merit](https://codeofmerit.org/code/) Clause 8)
- Participation on the project equates to agreement of this modified code of conduct.